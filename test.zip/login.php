<?php
  $hn='localhost';
  $db='shop';
  $un='root';
  $pw='!dch62yh!KxB';
?>